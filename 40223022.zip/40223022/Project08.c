// Nazanin Zahra Taghizadeh 40223022
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct time
{
    int min;
    int sec;
};
struct runner
{
    char firstName[30];
    char lastName[30];
    int ID;
    struct time *record;
    struct time runningTime;
};
struct tot
{
    struct runner r;
};
int main(void)
{    
    char firstname[30];
    char Lastname[30];
    printf("Hello welcome to this Project\n");
    printf("Please enter the number of runners :\t");
    int n;
    scanf("%d",&n);
    struct runner run[n];
    struct tot rn[n];
    struct tot re;
    for (int i=0; i<n; ++i)
    { 
        run[i].record=(struct time*)malloc(sizeof(struct time ));
        printf("\nplease enter the first name :\t");
        scanf("%s",&run[i].firstName);
        printf("\nPlease enter the last name :\t");
        scanf("%s",&run[i].lastName);
        printf("\nPlease enter the ID :\t");
        scanf("%d",&run[i].ID);
        printf("\nPlease enter the record min :\t");
        scanf("%d",&run[i].record->min);
        printf("\nPlease enter the record sec :\t");
        scanf("%d",&run[i].record->sec);
        printf("\nPlease enter the running time min :\t");
        scanf("%d",&run[i].runningTime.min);
        printf("\nPlease enter the running time sec :\t");
        scanf("%d",&run[i].runningTime.sec);
    }
    int max=run[0].runningTime.sec;
    int Max=run[0].runningTime.min;
    int recordmin=run[0].record->min;
    int recordsec=run[0].record->sec;
    int id=run[0].ID;
    for (int j=1; j<n; ++j)
    {
        if ((run[j].runningTime.min<Max)|| ((run[j].runningTime.min==Max) && (run[j].runningTime.sec< max)))
        {
            strcpy(firstname,run[j].firstName);
            strcpy(Lastname,run[j].lastName);
           Max=run[j].runningTime.min;
           max=run[j].runningTime.sec;
           recordmin=run[j].record->min;
           recordsec=run[j].record->sec;
        }
    }
        printf("%s\t", firstname);
        printf("%s", Lastname);
    
    if ((Max<recordmin) || ((Max==recordmin) && (max<recordsec)))
     printf("\nBroke record!");
    else 
     printf("\n Didn't break record\n");
    int maxr=run[0].record->sec;
    int Maxr=run[0].record->min;
        for (int k=1; k<n; ++k)
    {
        if (((run[k].record->min)<Maxr) || ((run[k].record->min==Maxr) && (run[k].record->sec< maxr)))
        {
           Maxr=run[k].record->min;
           maxr=run[k].record->sec;
        }
    }
    if ((Maxr>Max) || ((Maxr==Max) && (maxr>max)))
     printf("\nBroke the best record\n");
    else
     printf("Didn't break the best record\n");
     printf("firstname/lastname/ID/runnigtimemin/runningtimesec/recordmin/recordsec\n");
     for (int w=0 ; w<n ; ++w)
     {
        rn[w].r=run[w];
     }
     int p;
     int e;
     for (e=0; e<(n-1); ++e)
     {
      for (p=0; p<(n-e-1) ; ++p)
       {
        if (((rn[p].r.record->min>rn[p+1].r.record->min) || ((rn[p].r.record->min==rn[p+1].r.record->min) && (rn[p].r.record->sec>rn[p+1].r.record->sec))))
        {   
            re.r=rn[p].r;
            rn[p].r=rn[p+1].r;
            rn[p+1].r=re.r;

        }
       }
      }
     for ( int a=0; a<n ; ++a)
     {
        printf("%s %s , %d , %d : %d , %d : %d \n",rn[a].r.firstName,rn[a].r.lastName, rn[a].r.ID, rn[a].r.runningTime.min,rn[a].r.runningTime.sec,rn[a].r.record->min,rn[a].r.record->sec);
     }
free(run);
return 0;
}






